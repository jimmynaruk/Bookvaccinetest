<!DOCTYPE html>
<html lang="en">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<style type="text/css">
@import  url("https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800&display=swap");

body {
    background-color: #eee;
    font-family: "Poppins", sans-serif;
    font-weight: 300
}

.container {
    height: 100vh
}

.card {
    width: 400px;
    border: none
}

.form-control {
    border: 2px solid #bdc1d2;
    font-size: 13px;
    height: 48px
}

.form-control:focus {
    color: #495057;
    background-color: #fff;
    border-color: #f7bfd9;
    outline: 0;
    box-shadow: none
}

.form {
    position: relative;
    margin-bottom: 25px
}

.form a {
    position: absolute;
    right: 8px;
    bottom: 10px;
    color: #6ca0d6;
    font-size: 13px;
    text-decoration: none;
    z-index: 10;
    background-color: #fff;
    padding: 5px
}

.continue {
    height: 48px;
    font-size: 13px;
    background-color: #e91e63;
    border: none
}

.line-text {
    color: #cecece
}

.line {
    background-color: #eeeff6;
    width: 166px;
    height: 2px
}

.member a {
    color: #e91e63;
    font-size: 14px
}

.member span {
    font-size: 13px;
    font-weight: 400;
    color: #6ca0d6
}

.facebook-button {
    background-color: #39559f
}

.facebook-button:hover {
    background-color: #39559f
}

.facebook:focus {
    color: #fff;
    background-color: #4285f4;
    border-color: #4285f4;
    box-shadow: none
}

.google-button {
    background-color: #4285f4
}

.google-button:hover {
    background-color: #4285f4
}
</style>


<div class="container d-flex justify-content-center align-items-center">
    <div class="card">
        <div class="p-3 border-bottom d-flex align-items-center justify-content-center">
            <h5>เบอร์โทรศัพท์มือถือ / Mobile Number</h5>
        </div>
            <div class="p-3 px-4 py-4 border-bottom"> <input type="text" id="idteltxt"class="form-control mb-2" placeholder="กรอกเบอร์โทรศัพท์" />

            <button class="btn btn-success btn-block " onclick="createUser()">ลงทะเบียน</button>
            </div>
            </div>          
    </div>
</html>
<script>
function createUser(){
           
            idteltxt = $("#idteltxt").val();
          
           if(idteltxt==''){
           alert('กรุณากรอกเบอร์โทรศัพท์');
           return false;
           }
           $.ajax({
           type:"POST",
           url:'<?php echo e(URL::to("regis/createUser")); ?>', 
           data:{
            idteltxt: idteltxt,
         _token:"<?php echo e(csrf_token()); ?>"
         },success:function(result){
           alert(result.message);00
           window.location.reload();
         },fail:function(result,status,error){
           alert('failFunction');
         },error:function(result,status,error){
             let msg = result.responseJSON.message
           
               alert(msg);
         }
       
     })
   }
   function chkNumber(ele) //พิมพ์ได้เฉพาะตัวเลข
	{
  //var phoneno = /^(?([0-9]{3}))*-([0-9]{3})*-([0-9]{4})$/;
	var vchar = String.fromCharCode(event.keyCode);
	if ((vchar<'0' || vchar>'9') && (vchar != '.')) return false;
	ele.onKeyPress=vchar;
  }

  function checkText(ele)
	{
		var elem = String.fromCharCode(event.keyCode);
		if(!elem.match(/^([a-z0-9\_])+$/i)) return false;
		ele.onKeyPress=vchar;
		
	}

    function autoTab(obj){
    /* กำหนดรูปแบบข้อความโดยให้ _ แทนค่าอะไรก็ได้ แล้วตามด้วยเครื่องหมาย
    หรือสัญลักษณ์ที่ใช้แบ่ง เช่นกำหนดเป็น  รูปแบบเลขที่บัตรประชาชน
    4-2215-54125-6-12 ก็สามารถกำหนดเป็น  _-____-_____-_-__
    รูปแบบเบอร์โทรศัพท์ 08-4521-6521 กำหนดเป็น __-____-____
    หรือกำหนดเวลาเช่น 12:45:30 กำหนดเป็น __:__:__
    ตัวอย่างข้างล่างเป็นการกำหนดรูปแบบเลขบัตรประชาชน
    */
        var pattern=new String("___-___-____"); // กำหนดรูปแบบในนี้
        var pattern_ex=new String("-"); // กำหนดสัญลักษณ์หรือเครื่องหมายที่ใช้แบ่งในนี้
        var returnText=new String("");
        var obj_l=obj.value.length;
        var obj_l2=obj_l-1;
        for(i=0;i<pattern.length;i++){           
            if(obj_l2==i && pattern.charAt(i+1)==pattern_ex){
                returnText+=obj.value+pattern_ex;
                obj.value=returnText;
            }
        }
        if(obj_l>=pattern.length){
            obj.value=obj.value.substr(0,pattern.length);           
        }
}
   </script><?php /**PATH C:\xampp\htdocs\Bookvaccinetest\resources\views/regis.blade.php ENDPATH**/ ?>